package com.example.dutchpay

class ContentList {

    var name: String = ""
    var price: Int = 0
}